from dataclasses import fields 
from datetime import datetime
from multiprocessing import AuthenticationError
from tkinter import Widget
from turtle import width
from unittest.util import _MAX_LENGTH
from .models import Travelrequestheader,Travelflightdetails,Travelhoteldetails,Non_Emp_Details,Travelvisadetails,Travelforexdetails,Travelcarbookingdetails,Expenseclaimhead,Workbreakdownstructure,Pettycashdetails,Pettycashheader,Expenseclaimdetails,AdvanceRequestdetails,Divassignmentuser
from .models import  GradeModel,WorkcenterModel,DepartmentModel,Expenseheadmaster,Expensesubheadmaster,Basecostcenter,Projectmaster,Internalorder,EmployeeMaster,Advancerequesthead,Advancerequestsubheadmaster,Divmaster,Userrole,Titledetails                 
from django import forms
# from django.contrib.auth.forms import AuthenticationForm,UserCreationForm
from django.contrib.auth.models import User

class Loginform():
    username = forms.EmailField(widget=forms.TextInput(
        attrs={'class': 'form-control'}))
    password1 = forms.CharField(label='Password', widget=forms.PasswordInput(
        attrs={'class': 'form-control'}))


class Travelrequestheaderform(forms.ModelForm):
    
    TRHEMEMPCOD = forms.IntegerField(label="Employee Code",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '}))   
    # TRHCRTAT = forms.DateField(label='Created At',required=False,widget=forms.DateInput(attrs={'class': 'form-control','type':'date' }))
    TRHPROJTRVLFR = forms.CharField(label="Project Traveling For",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
    TRHPRPSOFVIS = forms.CharField(label="Purpose Of Visit",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
   
    class Meta:
        model = Travelrequestheader 
        fields = [ 
                  "TRHEMEMPCOD",
                  "TRHTRVTYP",
                  "TRHSTUSTYP",
                #   "TRHCRTAT",
                  "TRHPROJTRVLFR",
                  "TRHPRPSOFVIS",
                  ]
    
        widgets = {
                        "TRHTRVTYP":forms.Select(attrs={"class":"form-select"}),
                        "TRHSTUSTYP":forms.Select(attrs={"class":"form-select"}),
                }


class Travelflightdetailsform(forms.ModelForm):  
    # user = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
    TFLDDTEOFTRV = forms.DateField(label='Date Of Travel',required=False,widget=forms.DateInput(attrs={'class': 'form-control','type':'date' }))   
    TFLDFRMPLC = forms.CharField(label="From Place",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
    TFLDTOPLC = forms.DateField(label='To Place',required=False,widget=forms.DateInput(attrs={'class': 'form-control','type':'date' }))
    TFLDPREFTM = forms.CharField(label="Pref Time",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))    
    TFLDFLGTNO = forms.CharField(label="Flight No",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))    
    TFLDFRE = forms.CharField(label="Fare",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))   
    TFLDREMK = forms.CharField(label="Remark",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))


    class Meta:
        model = Travelflightdetails 
        fields = [ 
                  "TFLDDTEOFTRV",
                  "TFLDFRMPLC",
                  "TFLDTOPLC",
                  "TFLDPREFTM",
                  "TFLDFLGTNO",
                  "TFLDFRE",
                  "TFLDREMK",
                  ]


class Travelhoteldetailsform(forms.ModelForm):    
    # user = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
    THDPREFHOTL = forms.CharField(label="Preferred Hotel",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))   
    THDCHKINDTE = forms.DateField(label='Check In Date',required=False,widget=forms.DateInput(attrs={'class': 'form-control','type':'date' }))   
    THDCHKOTDTE = forms.DateField(label="Check Out Date",required=False, widget=forms.DateInput(attrs={'class': 'form-control','type':'date' }))      
    THDSECT = forms.CharField(label="Sector",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))    
    THDROMTYP = forms.CharField(label="Room Type",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))    
    THDSNGLDOBL = forms.CharField(label="Single/Double",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
   
    
    class Meta:
        model = Travelhoteldetails 
        fields = [ 
                  "THDPREFHOTL",
                  "THDCHKINDTE",
                  "THDCHKOTDTE",
                  "THDSECT",
                  "THDROMTYP",
                  "THDSNGLDOBL",
                  ]
    
    
class Non_Emp_Detailsform(forms.ModelForm):       
    # user = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
    TNEDNONEMPNAM = forms.CharField(label="Non Employee Nane",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
    TNEDPPRSOFVIS = forms.CharField(label="Purpose of Visit",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
    TNEDMOBLNO = forms.CharField(label="Mobile No",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
    TNEDEML = forms.EmailField(label="Email",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
    
    
    class Meta:
        model = Non_Emp_Details 
        fields = [ 
                  "TNEDNONEMPNAM",
                  "TNEDPPRSOFVIS",
                  "TNEDMOBLNO",
                  "TNEDEML",
                  ]


class Travelvisadetailsform(forms.ModelForm):      
    # user = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
    TVDTRAVDTE = forms.DateField(label="Travel Date",required=False, widget=forms.DateInput(attrs={'class': 'form-control','type':'date' }))  
    TVDVISTGCOUN = forms.CharField(label="Visiting Country",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
    TVDVSAFES = forms.CharField(label="Visa Fees",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
    TVDREMK = forms.CharField(label="Remarks",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
   
    class Meta:
        model = Travelvisadetails 
        fields = [ 
                  "TVDTRAVDTE",
                  "TVDVISTGCOUN",
                  "TVDVSAFES",
                  "TVDREMK",
                  ]
        
        
class Travelforexdetailsform(forms.ModelForm):    
    TFODTRAVDTE = forms.DateField(label="Travel Date",required=False, widget=forms.DateInput(attrs={'class': 'form-control','type':'date' }))  
    TFODSECT = forms.CharField(label="Sector",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
    TFODCURR = forms.CharField(label="Currency",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
   
        
    class Meta:
        model = Travelforexdetails 
        fields = [ 
                  "TFODTRAVDTE",
                  "TFODSECT",
                  "TFODCURR",                  
                  ]
        
        
class Travelcarbookingdetailsform(forms.ModelForm):
    TCBDTRAVDTE = forms.DateField(label="Travel Date",required=False, widget=forms.DateInput(attrs={'class': 'form-control','type':'date' }))  
    TCBDTM = forms.CharField(label="Time",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
    TCBDCARBOKGTYP = forms.CharField(label="Car Booking Type",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
    TCBDLOCL_OTSTAN =forms.CharField(label="Local/Outstation",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
    TCBDPKUP_DRP = forms.CharField(label="Pickup/Drop Address",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
    TCBDREMK = forms.CharField(label="Remarks",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
    
    class Meta:
        model = Travelcarbookingdetails 
        fields = [ 
                  "TCBDTRAVDTE",
                  "TCBDTM",
                  "TCBDCARBOKGTYP",
                  "TCBDLOCL_OTSTAN",
                  "TCBDPKUP_DRP",
                  "TCBDREMK",                  
                  ]
        

class Expenseclaimheadform(forms.ModelForm):
    ECHEHEDID = forms.IntegerField(label="Expense Head Id",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '}))
    ECHCLMMNT = forms.CharField(label="Expense Claim Month",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
    ECHCLMHEDASIGD = forms.CharField(label="Expense Claim Head",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
    ECHCLMHEDPYMTDTE = forms.DateField(label="Payment Date",required=False, widget=forms.DateInput(attrs={'class': 'form-control','type':'date' }))
           
    class Meta:
        model = Expenseclaimhead 
        fields = [ 
                  "ECHEHEDID",
                  "ECHCLMMNT",
                  "ECHCLMHEDASIGD",
                  "ECHCLMHEDPYMTDTE",
                  "ECHCLMSTUS",                  
                  ]
        
    widgets = {
                 "ECHCLMSTUS":forms.Select(attrs={"class":"form-select"}),
            }
    
    
class Workbreakdownstructureform(forms.ModelForm):
    WBSELMT = forms.CharField(label="WorkBreakdown Element",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
    WBSDESP = forms.CharField(label="WorkBreakdown Description",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
    WBSPMINTRID = forms.CharField(label="Project Id",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
    
    class Meta:
        model = Workbreakdownstructure 
        fields = [ 
                  "WBSELMT",
                  "WBSDESP",
                  "WBSPMINTRID",
                  "WBSSTUS",
                                    
                  ]
        
    widgets = {
                 "WBSSTUS":forms.Select(attrs={"class":"form-select"}),
            }
 
    
class Pettycashheaderform(forms.ModelForm):
    PCHCLMMNT = forms.CharField(label="Petty Cash Month",required=False, widget=forms.TextInput(attrs={'class': 'form-control '})) 
    PCHCLMHEDASIGD = forms.CharField(label="Petty Cash Assigned Manager",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))
    PCHHEDPYMTDTE = forms.DateField(label="Petty Cash Date",required=False, widget=forms.DateInput(attrs={'class': 'form-control','type':'date' }))
    PCHVCHRNO = forms.CharField(label="Voucher No",required=False, widget=forms.TextInput(attrs={'class': 'form-control '})) 
    PCHVCHRDTE = forms.DateField(label="Voucher Date",required=False, widget=forms.DateInput(attrs={'class': 'form-control','type':'date' }))
    
    class Meta:
        model = Pettycashheader 
        fields = [ 
                  "PCHCLMMNT",
                  "PCHCLMHEDASIGD",
                  "PCHHEDPYMTDTE",                 
                  "PCHVCHRNO",
                  "PCHVCHRDTE",
                  "PCHCLMSTUS",
                                    
                  ]
        
    widgets = {
                 "PCHCLMSTUS":forms.Select(attrs={"class":"form-select"}),
            }
    
    
class Pettycashdetailsform(forms.ModelForm):
    PCDTYP = forms.CharField(label="Petty Cash Type",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))  
    PCDHEDID = forms.IntegerField(label="Expense Head Id",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    PCDSBHDID = forms.IntegerField(label="Expense SubHead Id",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    PCDPROJID = forms.IntegerField(label="Expense Project Id",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    PCDWRKBRKDWNSTRCTRID = forms.IntegerField(label="Expense WBS Id",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    PCDINTRLORDRID = forms.IntegerField(label="Expense InternalOrder Id",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    PCDDTEOFCLM = forms.DateField(label="Date Of Claim",required=False, widget=forms.DateInput(attrs={'class': 'form-control','type':'date' })) 
    PCDWRKCNTR = forms.IntegerField(label="Petty Cash WorkCenter ",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    PCDBSECSTCNTR = forms.IntegerField(label="Base Cost Center",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    PCDEXPCSTCNTR = forms.IntegerField(label="Expense Cost Center",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    PCDDESP = forms.CharField(label="Petty Cash Description",required=False, widget=forms.TextInput(attrs={'class': 'form-control '})) 
    PCDAMT = forms.CharField(label="Petty Cash Amount",required=False, widget=forms.TextInput(attrs={'class': 'form-control '})) 
    PCDAPPVDAMT = forms.CharField(label="Petty Cash Approved Amount",required=False, widget=forms.TextInput(attrs={'class': 'form-control '})) 
    
    class Meta:
        model = Pettycashdetails 
        fields = [ 
                  "PCDTYP",
                  "PCDHEDID",
                  "PCDSBHDID",                 
                  "PCDPROJID",
                  "PCDWRKBRKDWNSTRCTRID",
                  "PCDINTRLORDRID",
                  "PCDDTEOFCLM",
                  "PCDWRKCNTR",
                  "PCDBSECSTCNTR",                 
                  "PCDDESP",
                  "PCDAMT",
                  "PCDAPPVDAMT",                                    
                
                ]
        
    
class Expenseclaimdetailsform(forms.ModelForm):
    ECDTYP = forms.CharField(label="Petty Cash Type",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))  
    ECDECHEHEDID = forms.IntegerField(label="Expense Head Id",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    ECDEXSSBHDID = forms.IntegerField(label="Expense SubHead Id",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    ECDPMPROJID = forms.IntegerField(label="Expense Project Id",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    ECDWRKBRKDWNSTRCTRID = forms.IntegerField(label="Expense WBS Id",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    ECDINTRLORDRID = forms.IntegerField(label="Expense InternalOrder Id",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    ECDDTEOFCLM = forms.DateField(label="Date Of Claim",required=False, widget=forms.DateInput(attrs={'class': 'form-control','type':'date' })) 
    ECDWRKCNTR = forms.IntegerField(label="Petty Cash WorkCenter ",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    ECDBSECSTCNTR = forms.IntegerField(label="Base Cost Center",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    ECDEXPCSTCNTR = forms.IntegerField(label="Expense Cost Center",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    ECDDESP = forms.CharField(label="Petty Cash Description",required=False, widget=forms.TextInput(attrs={'class': 'form-control '})) 
    ECDAMT = forms.CharField(label="Petty Cash Amount",required=False, widget=forms.TextInput(attrs={'class': 'form-control '})) 
    ECDAPPVDAMT = forms.CharField(label="Petty Cash Approved Amount",required=False, widget=forms.TextInput(attrs={'class': 'form-control '})) 
    
    class Meta:
        model = Expenseclaimdetails 
        fields = [ 
                  "ECDTYP",
                  "ECDECHEHEDID",
                  "ECDEXSSBHDID",                 
                  "ECDPMPROJID",
                  "ECDWRKBRKDWNSTRCTRID",
                  "ECDINTRLORDRID",
                  "ECDDTEOFCLM",
                  "ECDWRKCNTR",
                  "ECDBSECSTCNTR",                 
                  "ECDDESP",
                  "ECDAMT",
                  "ECDAPPVDAMT",                                    
                
                ]


class AdvanceRequestdetailsform(forms.ModelForm):
    ARDTYP = forms.CharField(label="Petty Cash Type",required=False, widget=forms.TextInput(attrs={'class': 'form-control '}))  
    ARDECDHEDID = forms.IntegerField(label="Expense Head Id",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    ARDECDSBHDID = forms.IntegerField(label="Expense SubHead Id",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    AARDECDPROJID = forms.IntegerField(label="Expense Project Id",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    ARDECDWRKBRKDWNSTRCTRID = forms.IntegerField(label="Expense WBS Id",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    ARDECDINTRLORDRID = forms.IntegerField(label="Expense InternalOrder Id",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    ARDDTEOFCLM = forms.DateField(label="Date Of Claim",required=False, widget=forms.DateInput(attrs={'class': 'form-control','type':'date' })) 
    ARDWRKCNTR = forms.IntegerField(label="Petty Cash WorkCenter ",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    ARDBSECSTCNTR = forms.IntegerField(label="Base Cost Center",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    ARDDESP = forms.CharField(label="Petty Cash Description",required=False, widget=forms.TextInput(attrs={'class': 'form-control '})) 
    ARDAMT = forms.CharField(label="Petty Cash Amount",required=False, widget=forms.TextInput(attrs={'class': 'form-control '})) 
    ARDAPPVDAMT = forms.CharField(label="Petty Cash Approved Amount",required=False, widget=forms.TextInput(attrs={'class': 'form-control '})) 
    
    class Meta:
        model = AdvanceRequestdetails 
        fields = [ 
                  "ARDTYP",
                  "ARDECDHEDID",
                  "ARDECDSBHDID",                 
                  "AARDECDPROJID",
                  "ARDECDWRKBRKDWNSTRCTRID",
                  "ARDECDINTRLORDRID",
                  "ARDDTEOFCLM",
                  "ARDWRKCNTR",
                  "ARDBSECSTCNTR",                 
                  "ARDDESP",
                  "ARDAMT",
                  "ARDAPPVDAMT",                                    
                
                ]
       
        
class Tileautherizationdetailsform(forms.ModelForm):
    TADTITDID = forms.CharField(label="Tile Id",required=False, widget=forms.TextInput(attrs={'class': 'form-control '})) 
    TADURROLTLE = forms.CharField(label="User Role Id",required=False, widget=forms.TextInput(attrs={'class': 'form-control '})) 
    TADDIVMINTRID = forms.CharField(label="Div Id ",required=False, widget=forms.TextInput(attrs={'class': 'form-control '})) 
    TADSEQ = forms.IntegerField(label="Sequence Id",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
    
    class Meta:
        model = AdvanceRequestdetails 
        fields = [ 
                  "TADTITDID",
                  "TADURROLTLE",
                  "TADSEQ", 
        ]
        

class Divassignmentuserform(forms.ModelForm):
    DIVASSUURROLTLE = forms.CharField(label="User Role",required=False, widget=forms.TextInput(attrs={'class': 'form-control '})) 
    DIVASSUDIVMID = forms.CharField(label="Div Id",required=False, widget=forms.TextInput(attrs={'class': 'form-control '})) 
    DIVASSUSEQ = forms.IntegerField(label="Sequence Id",required=False, widget=forms.NumberInput(attrs={'class': 'form-control '})) 
   
   
    class Meta:
        model = Divassignmentuser 
        fields = [ 
                  "DIVASSUURROLTLE",
                  "DIVASSUDIVMID",
                  "DIVASSUSEQ", 
        ]
        
        
class Grade(forms.ModelForm):
    GDGRD = forms.CharField(label='Grade', required=True, error_messages={
        'required': 'Enter Grade'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    GDGRDDESP = forms.CharField(label='Description', required=True, error_messages={
        'required': 'Enter Description'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
        
    class Meta:
        model = GradeModel
        fields = [
            "GDGRD",
            "GDGRDDESP",
        ]


class Workcenter(forms.ModelForm):
    WCWRKCNTR = forms.CharField(label='Workcenter', required=True, error_messages={
        'required': 'Enter Workcenter'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    WCWRKCNTRDESP = forms.CharField(label='Description', required=True, error_messages={
        'required': 'Enter Description'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    
    class Meta:
        model = WorkcenterModel
        fields = [
            "WCWRKCNTR",
            "WCWRKCNTRDESP",
        ]


class Department(forms.ModelForm):
    DDDEPRT = forms.CharField(label='Department', required=True, error_messages={
        'required': 'Enter Department'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    DDDEPRTDESP = forms.CharField(label='Description', required=True, error_messages={
        'required': 'Enter Description'}, widget=forms.TextInput(attrs={'class': 'form-control'}))

    class Meta:
        model = DepartmentModel
        fields = [
            "DDDEPRT",
            "DDDEPRTDESP",
        ]


class Expenseheadmaster(forms.ModelForm):
    EXHEXPHEDID = forms.IntegerField(label='Head ID', required=True, error_messages={
        'required': 'Enter ID'}, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    EXHHEDTLE = forms.CharField(label='Title', required=True, error_messages={
        'required': 'Enter Title'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    EXHHEDDESP = forms.CharField(label='Description', required=True, error_messages={
        'required': 'Enter Description'}, widget=forms.TextInput(attrs={'class': 'form-control'}))

    class Meta:
        model = Expenseheadmaster
        fields = [
            "EXHEXPHEDID",
            "EXHHEDTLE",
            "EXHHEDDESP",
        ]


class Expensesubheadmaster(forms.ModelForm):
    EXSEXPID = forms.IntegerField(label='Subhead ID', required=True, error_messages={
        'required': 'Enter ID'}, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    EXSTLE = forms.CharField(label='Title', required=True, error_messages={
        'required': 'Enter Title'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    EXSDESP = forms.CharField(label='Description', required=True, error_messages={
        'required': 'Enter Description'}, widget=forms.TextInput(attrs={'class': 'form-control'}))

    class Meta:
        model = Expensesubheadmaster
        fields = [
            "EXSEXPID",
            "EXSTLE",
            "EXSDESP",
        ]


class Basecostcenter(forms.ModelForm):
    BCCDTLE = forms.CharField(label='Title', required=True, error_messages={
        'required': 'Enter Title'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    BCCDESP =  forms.CharField(label='Description', required=True, error_messages={
        'required': 'Enter Description'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    BCCEXPCSTCNTR =  forms.IntegerField(label='ID', required=True, error_messages={
        'required': 'Enter ID'}, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    
    class Meta:
        model = Basecostcenter
        fields = [
            "BCCDTLE",
            "BCCDESP",
            "BCCEXPCSTCNTR",
        ]


class Projectmaster(forms.ModelForm):
    PMPROJID = forms.IntegerField(label='Project ID', required=True, error_messages={
        'required': 'Enter ID'}, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    PMSTUS = forms.Select(attrs={"class":"form-select"})
    PMDESP = forms.CharField(label='Description', required=True, error_messages={
        'required': 'Enter Description'}, widget=forms.TextInput(attrs={'class': 'form-control'}))

    class Meta:
        model = Projectmaster
        fields = [
            "PMPROJID",
            "PMSTUS",
            "PMDESP",
        ]
    
    
class Internalorder(forms.ModelForm):
    IODINTRID = forms.IntegerField(label='Internal ID', required=True, error_messages={
        'required': 'Enter ID'}, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    IODSTUS = forms.Select(attrs={"class":"form-select"})
    IODDESP = forms.CharField(label='Description', required=True, error_messages={
        'required': 'Enter Description'}, widget=forms.TextInput(attrs={'class': 'form-control'}))

    class Meta:
        model = Internalorder
        fields = [
            "IODINTRID",
            "IODSTUS",
            "IODDESP",
        ]


class EmployeeMaster(forms.ModelForm):
    EMEMPCOD = forms.IntegerField(label='Code', required=True, error_messages={
        'required': 'Enter code'}, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    EMEMLID = forms.CharField(label='Email Id', required=True, error_messages={
        'required': 'Enter Email'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    EMGRD = forms.CharField(label='Grade', required=True, error_messages={
        'required': 'Enter Grade'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    EMDESG = forms.CharField(label='Designation', required=True, error_messages={
        'required': 'Enter Designation'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    EMMOBLNO = forms.CharField(label='Mobile No', required=True, error_messages={
        'required': 'Enter Mobile No'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    EMDEPRT = forms.CharField(label='Department', required=True, error_messages={
        'required': 'Enter Department'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    EMWRKCNTR = forms.CharField(label='Workcenter', required=True, error_messages={
        'required': 'Enter Workcenter'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    EMCOMPNAM = forms.CharField(label='Company Name', required=True, error_messages={
        'required': 'Enter Company Name'}, widget=forms.TextInput(attrs={'class': 'form-control'}))

    class Meta:
        model = EmployeeMaster
        fields = [
            "EMEMPCOD",
            "EMEMLID",
            "EMGRD",
            "EMDESG",
            "EMMOBLNO",
            "EMDEPRT",
            "EMWRKCNTR",
            "EMCOMPNAM",
        ]


class Advancerequesthead(forms.ModelForm):
    ARHEMPCOD =  forms.IntegerField(label='Code', required=True, error_messages={
        'required': 'Enter code'}, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    ARHMNT = forms.CharField(label='Title', required=True, error_messages={
        'required': 'Enter Title'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    ARHSTUS = forms.Select(attrs={"class":"form-select"})
    ARHASIGD = forms.CharField(label='Title', required=True, error_messages={
        'required': 'Enter Title'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    ARHPYMTDTE = forms.CharField(label='Title', required=True, error_messages={
        'required': 'Enter Title'}, widget=forms.TextInput(attrs={'class': 'form-control'}))

    class Meta:
        model = Advancerequesthead
        fields = [
            "ARHEMPCOD",
            "ARHMNT",
            "ARHSTUS",
            "ARHASIGD",
            "ARHPYMTDTE",
        ]


class Advancerequestsubheadmaster(forms.ModelForm):
    ARSMID = forms.IntegerField(label='ID', required=True, error_messages={
        'required': 'Enter ID'}, widget=forms.NumberInput(attrs={'class': 'form-control'}))
    ARSMTLE = forms.CharField(label='Title', required=True, error_messages={
        'required': 'Enter Title'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    ARSMDESP = forms.CharField(label='Description', required=True, error_messages={
        'required': 'Enter Description'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    
    class Meta:
        model = Advancerequestsubheadmaster
        fields = [
            "ARSMID",
            "ARSMTLE",
            "ARSMDESP",
        ]


class Divmaster(forms.ModelForm):
    DIVMID = forms.CharField(label='ID', required=True, error_messages={
        'required': 'Enter ID'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    DIVMTLE = forms.CharField(label='Title', required=True, error_messages={
        'required': 'Enter Title'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    DIVMDESP = forms.CharField(label='Description', required=True, error_messages={
        'required': 'Enter Description'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    
    class Meta:
        model = Divmaster
        fields = [
            "DIVMID",
            "DIVMTLE",
            "DIVMDESP",
        ]


class Userrole(forms.ModelForm):
    URROLTLE = forms.CharField(label='Title', required=True, error_messages={
        'required': 'Enter Title'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    URROLDESP = forms.CharField(label='Description', required=True, error_messages={
        'required': 'Enter Description'}, widget=forms.TextInput(attrs={'class': 'form-control'}))

    class Meta:
        model = Userrole
        fields = [
            "URROLTLE",
            "URROLDESP",
        ]


class Titledetails(forms.ModelForm):
    TITDID = forms.CharField(label='ID', required=True, error_messages={
        'required': 'Enter ID'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    TITDTLTLE = forms.CharField(label='Title', required=True, error_messages={
        'required': 'Enter Title'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    TITDDESP = forms.CharField(label='Description', required=True, error_messages={
        'required': 'Enter Description'}, widget=forms.TextInput(attrs={'class': 'form-control'}))
    TITDURL = forms.CharField(label='URL', required=True, error_messages={
        'required': 'Enter URL'}, widget=forms.TextInput(attrs={'class': 'form-control'}))

    class Meta:
        model = Titledetails
        fields = [
            "TITDID",
            "TITDTLTLE",
            "TITDDESP",
            "TITDURL",
        ]

