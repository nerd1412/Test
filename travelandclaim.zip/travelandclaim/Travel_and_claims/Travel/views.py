from django.shortcuts import render
from django.contrib.auth.models import User
from django.shortcuts import redirect, render
from Travel.forms import Grade,Workcenter,Department,Loginform
from .models import GradeModel,WorkcenterModel,DepartmentModel
# from travel.forms import Travelform, Loginform
from django.contrib import messages
# Create your views here.
from django.contrib.auth import authenticate,login
from django.core.paginator import Paginator
from django.db.models import Sum
from django.contrib.auth.forms import AuthenticationForm

# from Travel.forms import CreateUserform


def mylogin(req):
    print(req.method)
    if req.method=='POST':
        form = AuthenticationForm(req.POST)
        username = req.POST['username']
        password = req.POST['password']
        if username and password :
            user = authenticate(req,username=username,password=password)
            if user:
                login(req,user)
                # if not req.user.is_superuser:
                #     req.session['pid']=PersonalModel.objects.filter(user=req.user)[0].pk
                messages.success(req,"Login Successfull.")
                # print(user.is_superuser)
                # if user.is_superuser:
                #     return redirect('/admin')
                return redirect("/grade_save")
            else:
                messages.error(req,"Invalid Username or Password")
        else:
            messages.error(req,"Please Enter the username and Password")
    else:
        form = AuthenticationForm()
    return render(req,'login.html',{'form':form})

def grade_save(request):
    ctx ={}
    form = Grade(request.POST or None)
    if form.is_valid():
        print("valid")
        form = form.save()
        form.user = request.user
        form.save()
        messages.success(request,"Details added")
        form = Grade()
        print("Saved")
    else:
        print(form.errors)   
    # context['form']= form
    data = GradeModel.objects.all()
    paginator = Paginator(data, 10)
    page_number = 0
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    nums = "a" * page_obj.paginator.num_pages
    ctx={
        # 'data':data,
        'page_obj': page_obj,
        'nums': nums,
        'form':form
    }
    return render(request, "grade.html", ctx)


def grade_edit(request,id):
    ge = GradeModel.objects.get(pk=id)   
    if request.method == 'POST':
        form = Grade(request.POST,instance=ge)
        form.save()
        messages.success(request,"Data is updated")
    else:
        form = Grade(instance=ge)
    return render(request,'grade_edit.html',{'gform':form, 'g': ge })



def work_save(request):
    ctx ={}
    form = Workcenter(request.POST or None)
    if form.is_valid():
        print("valid")
        form = form.save()
        form.user = request.user
        form.save()
        messages.success(request,"Details added")
        form = Workcenter()
        print("Saved")
    else:
        print(form.errors)
    data = WorkcenterModel.objects.all()
    paginator = Paginator(data, 10)
    page_number = 0
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    nums = "a" * page_obj.paginator.num_pages
    ctx={
        # 'data':data,
        'page_obj': page_obj,
        'nums': nums,
        'form':form
    }
    return render(request, 'workcenter.html', ctx)



def work_edit(request,id):
    we = WorkcenterModel.objects.get(pk=id)   
    if request.method == 'POST':
        form = Workcenter(request.POST,instance=we)
        form.save()
        messages.success(request,"Data is updated")
    else:
        form = Workcenter(instance=we)
    
    return render(request,'workcenter_edit.html',{'wform':form, 'w': we })


def depart_save(request):
    ctx ={}
    form = Department(request.POST or None)
    if form.is_valid():
        print("valid")
        form = form.save()
        form.user = request.user
        form.save()
        messages.success(request,"Details added")
        form = Department()
        print("Saved")
    else:
        print(form.errors)
    data = DepartmentModel.objects.all()
    paginator = Paginator(data, 10)
    page_number = 0
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    nums = "a" * page_obj.paginator.num_pages
    ctx={
        # 'data':data,
        'page_obj': page_obj,
        'nums': nums,
        'form':form
    }
    return render(request, "depart.html", ctx)

def depart_edit(request,id):
    de = DepartmentModel.objects.get(pk=id)   
    if request.method == 'POST':
        form = Department(request.POST,instance=de)
        form.save()
        messages.success(request,"Data is updated")
    else:
        form = Department(instance=de)
    
    return render(request,'depart_edit.html',{'dform':form, 'd': de })

