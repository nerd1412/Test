"""Travel_and_claims URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django import views
from django.contrib import admin
from django.urls import path,include
from Travel import views

urlpatterns = [
    path("",views.mylogin,name='mylogin'),
    path('admin/', admin.site.urls),
    path("grade_save", views.grade_save, name="grade_save"),
    path("grade_edit/<int:id>", views.grade_edit, name="grade_edit"),
    path("work_save", views.work_save, name="work_save"),
    path("work_edit/<int:id>", views.work_edit, name="work_edit"),
    path("depart_save", views.depart_save, name="depart_save"),
    path("depart_edit/<int:id>", views.depart_edit, name="depart_edit"),
]
